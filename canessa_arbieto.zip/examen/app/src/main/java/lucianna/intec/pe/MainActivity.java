package lucianna.intec.pe;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    EditText inputText;
    Button generateQRButton, sendEmailButton;
    ImageView qrImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputText = findViewById(R.id.inputText);
        generateQRButton = findViewById(R.id.generateQRButton);
        sendEmailButton = findViewById(R.id.sendEmailButton);
        qrImageView = findViewById(R.id.qrImageView);

        generateQRButton.setOnClickListener(v -> generateQRCode());
        sendEmailButton.setOnClickListener(v -> sendZipByEmail());
    }

    private void generateQRCode() {
        String text = inputText.getText().toString();
        if (text.isEmpty()) {
            Toast.makeText(this, "Ingrese texto para el QR", Toast.LENGTH_SHORT).show();
            return;
        }

        BarcodeEncoder encoder = new BarcodeEncoder();
        try {
            Bitmap bitmap = encoder.encodeBitmap(text, BarcodeFormat.QR_CODE, 400, 400);
            qrImageView.setImageBitmap(bitmap);
            MediaStore.Images.Media.insertImage(getContentResolver(), bitmap, "QR_Code", null);
        } catch (WriterException e) {
            e.printStackTrace();
        }
    }

    private void sendZipByEmail() {
        File zipFile = new File(getExternalFilesDir(null), "carpeta_comprimida.zip");

        if (!zipFile.exists()) {
            Toast.makeText(this, "Archivo ZIP no encontrado", Toast.LENGTH_SHORT).show();
            return;
        }

        Uri zipUri = FileProvider.getUriForFile(
                this,
                getPackageName() + ".provider",
                zipFile
        );

        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setType("application/zip");
        emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{"BESTEBANV2@gmail.com"});
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Archivo ZIP desde app Android");
        emailIntent.putExtra(Intent.EXTRA_TEXT, "Adjunto el archivo comprimido.");
        emailIntent.putExtra(Intent.EXTRA_STREAM, zipUri);
        emailIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        startActivity(Intent.createChooser(emailIntent, "Enviar ZIP por correo..."));
    }
}
